#ifndef __MAP_UTIL_H__
#define __MAP_UTIL_H__

BOOL MAP_getMapDataFromCharIndex( int index  , int* map );
BOOL MAP_getMapDataFromFXY( int f , int x , int y, int* map );

#endif 
