#ifndef __NPC_SAMPLE_H__
#define __NPC_SAMPLE_H__

void NPC_SampleLoop( int index );

#endif 

 /*__NPC_SAMPLE_H__*/
