#ifndef __FUNCTION_H__
#define __FUNCTION_H__
BOOL initFunctionTable( void );
void* getFunctionPointerFromName( char* funcname );
#endif  
