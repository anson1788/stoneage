void MD5Digest(char   *pszInput,   unsigned   long   nInputSize,   char   *pszOutPut);
