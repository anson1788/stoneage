
void ShopData_Init();
void lssproto_upshopdata_recv(int fd,char shop[5][1024]);
void WriteShopData(char *data,int id);

