#ifndef __EVENT_H__
#define __EVENT_H__

INLINE	BOOL EVENT_CHECKEVENTINDEX( int event);
int EVENT_main( int charaindex,int event, int x, int y);


#endif

