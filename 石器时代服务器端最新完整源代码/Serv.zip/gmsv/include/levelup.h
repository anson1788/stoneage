#ifndef _LEVELUP_H
#define _LEVELUP_H

int GetEnemyExp( int level );

int BATTLE_GetLevelExp(
	int charaindex,
	int level
);

int BATTLE_LevelUpCheck(
	int charaindex
);


#endif

