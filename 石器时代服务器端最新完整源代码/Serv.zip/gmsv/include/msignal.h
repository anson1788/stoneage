#ifndef __SIGNAL_H__
#define __SIGNAL_H__

void signalset( void );
void shutdownProgram( void );
void sigshutdown( int number );

#endif
