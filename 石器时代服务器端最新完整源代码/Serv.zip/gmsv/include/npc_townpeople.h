#ifndef __NPC_TOWNPEOPLE_H__
#define __NPC_TOWNPEOPLE_H__

void NPC_TownPeopleTalked( int index, int talker, char *msg, int color );
void NPC_TownPeopleInit( int meindex );

#endif  /* __NPC_TOWNPEOPLE_H__ */
