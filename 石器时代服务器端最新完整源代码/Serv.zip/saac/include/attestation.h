#ifndef __ATTESTATION_H__
#define __ATTESTATION_H__
int attestation( void );

#endif
