#define _TESTMAC	   "00-07-40-E3-33-15"	//�Լ��Ĳ���MAC
#define _USERMAC1    "00-30-48-72-C0-56"  //52441740   �Yֻ������     222.223.133.2
#define _USERMAC2    "00-14-85-37-31-CA"  //22729177   1�����Ҷ��    58.33.147.183
#define _USERMAC3    "00-0B-6A-C5-B5-76"  //42813855   &&����m�F��   61.152.238.97
#define _USERMAC4    "00-13-46-66-86-52"  //10203543   ����           ���̶�
#define _USERMAC5    "00-00-00-00-00-00"
#define _USERMAC6    "00-00-00-00-00-00"
#define _USERMAC7    "00-00-00-00-00-00"
#define _USERMAC8    "00-00-00-00-00-00"
#define _USERMAC9    "00-00-00-00-00-00"
#define _USERMAC10   "00-00-00-00-00-00"
#define _USERMAC11   "00-00-00-00-00-00"
#define _USERMAC12   "00-00-00-00-00-00"
#define _USERMAC13   "00-00-00-00-00-00"
#define _USERMAC14   "00-00-00-00-00-00"
#define _USERMAC15   "00-00-00-00-00-00"
#define _USERMAC16   "00-00-00-00-00-00"
#define _USERMAC17   "00-00-00-00-00-00"
#define _USERMAC18   "00-00-00-00-00-00"
#define _USERMAC19   "00-00-00-00-00-00"
#define _USERMAC20   "00-00-00-00-00-00"
