#ifndef __CHARACTERS_H__
#define __CHARACTERS_H__
#ifdef _CHARADATA_SAVE_SQL

typedef struct tagChardata
{
	char *CHAR_list_String;
	char *CHAR_list_info1_String;
	char *CHAR_list_info2_String;
	char *CHAR_list_count_String;
	char *CHAR_list_info3_String;
	char *CHAR_list_event_String;
	char *CHAR_list_info4_String;
	char *CHAR_list_attackmagic_String;
	char *CHAR_list_info5_String;
	char *CHAR_list_profession_String;
	char *CHAR_list_info6_String;
	char *CHAR_list_info_String;
	char *CHAR_list_flg_String;
	char *CHAR_list_skill_String;
	char *CHAR_list_item_String;
	char *CHAR_list_title_String;
	char *CHAR_list_mail_String;
}Charadata;


#endif
#endif
